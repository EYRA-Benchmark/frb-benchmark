<?PHP
include("../definitions_i.php");
include("../functions_i.php");

?>

<HTML>

<?
$title = "APSR | Testing";
include("../header_i.php");

?>

<FRAMESET COLS="1" ROWS="60px,220px,*" border=1 bordercolor="#777777">
  <FRAME name="banner" src="/apsr/statebanner.php" frameborder=0 marginheight=0 marginwidth=0></FRAME>
  <FRAME name="tcs" src="tcs_interface.php"></FRAME>
  <FRAME name="tcs_interface" src=""></FRAME>
</FRAMESET>
</HTML>
