When installing a new instrument, or configuring/switching between
instruments, the following 3 soft links must be created/updated:

  <instr>.cfg    -> dada.cfg
  <instr>.info   -> dada.info
  <instr>.viewer -> dada.viewer

The dada_reconfigure.pl perl script will do this for you if you
run it manually
