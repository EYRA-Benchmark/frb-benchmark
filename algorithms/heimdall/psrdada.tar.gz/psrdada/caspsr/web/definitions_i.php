<?PHP
  define(INSTRUMENT, "caspsr");
  $instrument = "caspsr";
?>
